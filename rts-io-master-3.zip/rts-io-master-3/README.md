# rts-io
## Overview
### Game
 * “Space” Colonization
 * RTS style
 * Scaled by having a home tile surrounded by empty “planets” and empty space generate when a new player joins
 * Empty “planets” have a random set amount/kind of resources
 * Empty “planets” have a random set amount of space to build improvements
 * Empty tiles are used for unit/trade movement
 * Either .io speed OR traditional/slower pace based on balancing choices
### Technical:
 Backend + Server: Python/Django
 
 Web Frontend: TypeScript/VueJS
 
 Desktop Frontend: TBD
## Initial Work Division Plan:
 Jonathan - Client
 
 Kemeel, Avi - Backend Logic
 
 Andrew - Networking
