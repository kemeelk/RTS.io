const BundleTracker = require('webpack-bundle-tracker');

module.exports = {
  configureWebpack: {
    plugins: [
      new BundleTracker({ filename: './webpack-stats.json' }),
    ],
    devServer: {
      headers: {
        'Access-Control-Allow-Origin': '*',
      },
    },
  },
  publicPath: process.env.NODE_ENV === 'development' ? 'http://localhost:8080/' : '',
};
